package com.example.pramila.bakingapp.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.pramila.bakingapp.R;
//import com.example.pramila.bakingapp.ui.IngredientFragment.OnListFragmentInteractionListener;
import com.example.pramila.bakingapp.models.Ingredient;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * {@link RecyclerView.Adapter} that can display a {@link Ingredient} and makes a call to the
 * specified {@link //OnListFragmentInteractionListener}.
 * TODO: Replace the implementation with code for your data type.
 */
public class IngredientRecyclerViewAdapter extends RecyclerView.Adapter<IngredientRecyclerViewAdapter.ViewHolder> {

    private ArrayList<Ingredient> ingredients;
    private Context mContext;
    //private final OnListFragmentInteractionListener mListener;

    public IngredientRecyclerViewAdapter(Context context, ArrayList<Ingredient> items) {
        mContext =context;
        ingredients =items;
        //mListener = listener;
    }

    public ArrayList<Ingredient> getIngredients() {
        return ingredients;
    }

    public void setIngredients(ArrayList<Ingredient> ingredients) {
        this.ingredients = ingredients;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_ingredient, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        String ingredientText=ingredients.get(position).getIngredient_name()+" - "
                + ingredients.get(position).getQuantity()+" "+ingredients.get(position).getMeasure();
        holder.mIngredientText.setText(ingredientText);
        //holder.mItem = ingredients.get(position);
        //holder.mIdView.setText(ingredients.get(position).id);
        //holder.mContentView.setText(ingredients.get(position).content);


        /*holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != mListener) {
                    // Notify the active callbacks interface (the activity, if the
                    // fragment is attached to one) that an item has been selected.
                    mListener.onListFragmentInteraction(holder.mItem);
                }
            }
        });*/
    }

    @Override
    public void onAttachedToRecyclerView(@NonNull RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    @Override
    public int getItemCount() {
        return ingredients.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.bullet) TextView mbullet;
        @BindView(R.id.ingredient_name) TextView mIngredientText;

        public ViewHolder(View view) {
            super(view);
            ButterKnife.bind(this,view);
        }


        /*@Override
        public String toString() {
            return super.toString() + " '" + mContentView.getText() + "'";
        }*/
    }
}
