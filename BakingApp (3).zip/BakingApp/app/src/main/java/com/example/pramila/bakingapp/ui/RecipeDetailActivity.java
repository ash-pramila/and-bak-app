package com.example.pramila.bakingapp.ui;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.example.pramila.bakingapp.R;
import com.example.pramila.bakingapp.adapters.IngredientRecyclerViewAdapter;
import com.example.pramila.bakingapp.adapters.StepRecyclerViewAdapter;
import com.example.pramila.bakingapp.models.Ingredient;
import com.example.pramila.bakingapp.models.Recipe;
import com.example.pramila.bakingapp.models.Step;
import com.example.pramila.bakingapp.utils.Constant;

import java.util.List;

public class RecipeDetailActivity extends AppCompatActivity implements StepRecyclerViewAdapter.OnListFragmentListener{

    Recipe recipe;
    /*List<Ingredient> ingredients;
    IngredientRecyclerViewAdapter ingredientAdapter;*/
    public static boolean mTwoPane=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_ingredient_list);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Intent intent=getIntent();
        //recipe=(Recipe) intent.getSerializableExtra(Constant.RECIPE_INTENT_EXTRA);
        recipe=intent.getParcelableExtra(Constant.RECIPE_INTENT_EXTRA);
        if(recipe==null){
            Toast.makeText(this,getResources().getString(R.string.error_toast_text),Toast.LENGTH_LONG).show();
            finish();
        }
        setTitle(recipe.getName());
        mTwoPane=findViewById(R.id.tab_recipe_detail_layout)!=null;
        setData();

    }
    public void setData(){
        IngredientFragment ingredientFragment = new IngredientFragment();
        ingredientFragment.setIngredientList(recipe.getIngredients());
        ingredientFragment.setStepArrayList(recipe.getSteps());
        ingredientFragment.setOnListFragmentListener(this);
        if(!mTwoPane) {
            //For phone layout
            //IngredientFragment ingredientFragment = new IngredientFragment();
            //ingredientFragment.setIngredientList(recipe.getIngredients());
            //ingredientFragment.setStepArrayList(recipe.getSteps());
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.list, ingredientFragment).commit();
        }else{
            //For Tablet Layout
            /*
            StepDetailFragment stepDetailFragment=new StepDetailFragment();
        stepDetailFragment.setStep(steps);
        getSupportFragmentManager().beginTransaction()
                .add(R.id.list,stepDetailFragment).commit();
             */
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.tab_recipe_detail_layout, ingredientFragment).commit();
            StepDetailFragment stepDetailFragment=new StepDetailFragment();
            //stepDetailFragment=new StepDetailFragment();
            stepDetailFragment.setStep(recipe.getSteps().get(0));
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.tab_step_detail_layout,stepDetailFragment).commit();
        }
    }

    @Override
    public void onClick(Step stepData) {
        if(stepData==null)return;
        if(mTwoPane){
            //Toast.makeText(this, "Step:"+stepData.getShortDescription(), Toast.LENGTH_SHORT).show();
            StepDetailFragment stepDetailFragment=new StepDetailFragment();
            stepDetailFragment.setStep(stepData);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.tab_step_detail_layout,stepDetailFragment).commit();
        }else{
            //Toast.makeText(this, "Step:"+stepData.getShortDescription(), Toast.LENGTH_SHORT).show();
            Intent stepDetailIntent=new Intent(this,StepDetailActivity.class);
            stepDetailIntent.putExtra(Constant.STEP_INTENT_EXTRA,stepData);
            startActivity(stepDetailIntent);
        }
    }

    public static boolean ismTwoPane() {
        return mTwoPane;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable(Constant.RECIPE_INTENT_EXTRA,recipe);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        recipe=savedInstanceState.getParcelable(Constant.RECIPE_INTENT_EXTRA);
    }
}
