package com.example.pramila.bakingapp.utils;

import com.example.pramila.bakingapp.models.Ingredient;
import com.example.pramila.bakingapp.models.Recipe;
import com.example.pramila.bakingapp.models.Step;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by pramila on 19-08-2018 in ${Package_Name}.
 */
public class JsonUtils {
    //static ArrayList<Ingredient> ingredientsArrayList=new ArrayList<>();
    //static ArrayList<Step> stepsArrayList=new ArrayList<>();
    static List<Ingredient> ingredientsList;
    static List<Step> stepsList;
    public static ArrayList<Recipe> getRecipes(String recipesJsonData){
        ArrayList<Recipe> recipeList=new ArrayList<>();
        if (recipesJsonData==null)
            return null;
        try{
            JSONArray root=new JSONArray(recipesJsonData);
            for (int i=0;i<root.length();i++){
                ArrayList<Ingredient> ingredientsArrayList=new ArrayList<>();
                ArrayList<Step> stepsArrayList=new ArrayList<>();
                JSONObject recipeData=root.getJSONObject(i);
                String id=recipeData.getString(Constant.RECIPE_ID);
                //String id=recipeData.getString(Constant.RECIPE_NAME);
                String name=recipeData.getString(Constant.RECIPE_NAME);
                String servings=recipeData.getString(Constant.RECIPE_SERVINGS);
                String image=recipeData.getString(Constant.RECIPE_IMAGE);
                //recipeList.add(new Recipe(id,name,servings,image));
                JSONArray ingredients=recipeData.getJSONArray(Constant.RECIPE_INGREDIENT);
                for (int j=0;j<ingredients.length();j++){
                    JSONObject ingredientsData=ingredients.getJSONObject(j);
                    String ingredQuant=ingredientsData.getString(Constant.INGREDIENT_QUANTITY);
                    String ingredMeas=ingredientsData.getString(Constant.INGREDIENT_MEASURE);
                    String ingredName=ingredientsData.getString(Constant.INGREDIENT_NAME);
                    ingredientsArrayList.add(new Ingredient(name,ingredQuant,ingredMeas,ingredName));// using name instead of id
                }
                JSONArray steps=recipeData.getJSONArray(Constant.RECIPE_STEP);
                for (int j=0;j<steps.length();j++){
                    JSONObject stepsData=steps.getJSONObject(j);
                    String stepId=stepsData.getString(Constant.STEP_ID);
                    String stepShortDesc=stepsData.getString(Constant.STEP_SHORT_DESC);
                    String stepDesc=stepsData.getString(Constant.STEP_DESC);
                    String stepVideoUrl=stepsData.getString(Constant.STEP_VIDEO_URL);
                    String stepThumbnailUrl=stepsData.getString(Constant.STEP_THUMBNAIL_URL);
                    stepsArrayList.add(new Step(name,stepId,stepShortDesc,stepDesc,stepVideoUrl,stepThumbnailUrl));//using name instead of id
                }
                ingredientsList=ingredientsArrayList;
                stepsList=stepsArrayList;
                recipeList.add(new Recipe(id,name,servings,image,ingredientsList,stepsList));
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return recipeList;
    }

    /*public static ArrayList<Ingredient> getIngredientsList() {
        return ingredientsList;
    }

    public static void setIngredientsList(ArrayList<Ingredient> ingredientsList) {
        JsonUtils.ingredientsList = ingredientsList;
    }

    public static ArrayList<Step> getStepsList() {
        return stepsList;
    }

    public static void setStepsList(ArrayList<Step> stepsList) {
        JsonUtils.stepsList = stepsList;
    }*/
}
