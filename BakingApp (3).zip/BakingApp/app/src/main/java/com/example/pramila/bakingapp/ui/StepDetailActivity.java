package com.example.pramila.bakingapp.ui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.example.pramila.bakingapp.R;
import com.example.pramila.bakingapp.models.Recipe;
import com.example.pramila.bakingapp.models.Step;
import com.example.pramila.bakingapp.utils.Constant;

import java.util.ArrayList;

public class StepDetailActivity extends AppCompatActivity {

    Step steps;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_ingredient_list);
        Intent intent=getIntent();
        steps=(Step) intent.getSerializableExtra(Constant.STEP_INTENT_EXTRA);
        if(steps==null){
            Toast.makeText(this,getResources().getString(R.string.error_toast_text),Toast.LENGTH_LONG).show();
            finish();
        }
        setTitle(steps.getRecipeId());
        StepDetailFragment stepDetailFragment=new StepDetailFragment();
        stepDetailFragment.setStep(steps);
        getSupportFragmentManager().beginTransaction()
                .add(R.id.list,stepDetailFragment).commit();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable(Constant.RECIPE_STEP,steps);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        steps=(Step) savedInstanceState.getSerializable(Constant.RECIPE_STEP);
    }
}
