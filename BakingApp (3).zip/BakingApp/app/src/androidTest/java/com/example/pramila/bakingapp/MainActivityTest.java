package com.example.pramila.bakingapp;
import android.support.test.espresso.Espresso;
import android.support.test.espresso.IdlingResource;
import android.support.test.espresso.matcher.ViewMatchers;
import android.support.test.espresso.contrib.RecyclerViewActions;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.*;
import android.support.v7.widget.RecyclerView;

import com.example.pramila.bakingapp.ui.MainActivity;
import com.example.pramila.bakingapp.utils.Constant;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onData;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.assertion.ViewAssertions.matches;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.anything;

/**
 * Created by pramila on 08-09-2018 in ${Package_Name}.
 */

@RunWith(AndroidJUnit4.class)
public class MainActivityTest {
    //String CHECK_RECIPE_NAME="Nutella Pie";

    @Rule
    public ActivityTestRule<MainActivity> mMainActivityTestRule=new ActivityTestRule<>(MainActivity.class);

    private IdlingResource mIdlingResource;

    @Before
    public void registerIdlingResource(){
        mIdlingResource=mMainActivityTestRule.getActivity().getIdlingResource();
        Espresso.registerIdlingResources(mIdlingResource);
    }

    //PhoneTest
    @Test
    public void checkListInMainActivity(){
        //onView(withId(R.id.recipes_recycler_view)).perform(RecyclerViewActions.actionOnItemAtPosition(0,click()));
        onView(ViewMatchers.withId(R.id.recipes_recycler_view)).perform(RecyclerViewActions.scrollToPosition(0));
        ///onView(withId(R.id.recipe_name)).check(matches(isDisplayed()));
        onView(withText(Constant.CHECK_RECIPE_NAME_TEST)).check(matches(isDisplayed()));
        //onData(anything()).inAdapterView(with)
    }

    //PhoneTest
    @Test
    public void checkRecipeDetailActivity(){
        onView(ViewMatchers.withId(R.id.recipes_recycler_view)).perform(RecyclerViewActions.scrollToPosition(1));
        onView(ViewMatchers.withId(R.id.recipes_recycler_view)).perform(RecyclerViewActions.actionOnItemAtPosition(1,click()));
        onView(ViewMatchers.withId(R.id.steps_recycler_view)).perform(RecyclerViewActions.actionOnItemAtPosition(0,click()));
        onView(withId(R.id.step_text)).check(matches(isDisplayed()));
        //onView(withId(R.id.video_player)).check(matches(isDisplayed()));
    }

    @After
    public void unregisterIdlingResource(){
        if(mIdlingResource!=null)
            Espresso.unregisterIdlingResources(mIdlingResource);
    }
}
