package com.example.pramila.bakingapp.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.example.pramila.bakingapp.models.Ingredient;
import com.example.pramila.bakingapp.models.Recipe;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.CONNECTIVITY_SERVICE;
import static android.content.Context.MODE_PRIVATE;

/**
 * Created by pramila on 19-08-2018 in ${Package_Name}.
 */
public class Constant {
    /*[{
        "id": 1,
            "name": "Nutella Pie",
            "ingredients": [
        {
            "quantity": 2,
                "measure": "CUP",
                "ingredient": "Graham Cracker crumbs"
        },
        ],
    "steps": [
      {
        "id": 0,
        "shortDescription": "Recipe Introduction",
        "description": "Recipe Introduction",
        "videoURL": "https://d17h27t6h515a5.cloudfront.net/topher/2017/April/58ffd974_-intro-creampie/-intro-creampie.mp4",
        "thumbnailURL": ""
      },
"servings": 8,
    "image": ""
  },
*/

    public final static String RECIPE_BASIC_URL="https://d17h27t6h515a5.cloudfront.net/topher/2017/May/59121517_baking/baking.json";
    public final static String RECIPE_ID="id";
    public final static String RECIPE_NAME="name";
    public final static String RECIPE_SERVINGS="servings";
    public final static String RECIPE_IMAGE="image";
    public final static String RECIPE_INGREDIENT ="ingredients";
    public final static String INGREDIENT_QUANTITY="quantity";
    public final static String INGREDIENT_MEASURE="measure";
    public final static String INGREDIENT_NAME="ingredient";
    public final static String RECIPE_STEP ="steps";
    public final static String STEP_ID=RECIPE_ID;
    public final static String STEP_SHORT_DESC="shortDescription";
    public final static String STEP_DESC="description";
    public final static String STEP_VIDEO_URL="videoURL";
    public final static String STEP_THUMBNAIL_URL="thumbnailURL";
    public final static String CHECK_RECIPE_NAME_TEST="Nutella Pie";
    public final static String SHARED_PREFERENCE_KEY="key";
    public final static String SHARED_PREFERENCE_KEY_IN="inkey";
    public final static String SHARED_PREFERENCE_NAME="UserPreference";
    public final static String RECIPE_INTENT_EXTRA="Recipe";
    public final static String SAVE_PLAYER_POSITION_KEY="position";
    public final static String SAVED_PLAYER_WINDOW_INDEX="window";
    public final static String SAVED_PLAY_STATE="playwhenready";
    public final static String SAVED_IS_IMAGE="image";
    public final static int VIDEO_POTRAIT_SIZE=500;
    public final static int VIDEO_SIZE_FOR_IMAGE_IN_LAND=200;
    public final static String STEP_INTENT_EXTRA="stepData";


    public static boolean checkInternetConnection(Context context){
        ConnectivityManager connectivityManager=(ConnectivityManager)context.getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo=connectivityManager.getActiveNetworkInfo();
        if(networkInfo!=null && networkInfo.isConnected())
            return true;
        else
            return false;
    }

    /*To set recipes. Not used currently*/
    public static void setSharedPreference(Context context,ArrayList<Recipe> recipesShared) {
        //List<Recipe> recipes=recipesShared;
        String sharedPrefKey = SHARED_PREFERENCE_KEY;
        //String prefName = SHARED_PREFERENCE_NAME;
        SharedPreferences sharedPreferences;
        SharedPreferences.Editor editor;
        sharedPreferences = context.getSharedPreferences(SHARED_PREFERENCE_NAME, MODE_PRIVATE);
        Gson gson = new Gson();
        String json = gson.toJson(recipesShared);
        editor = sharedPreferences.edit();
        editor.remove(sharedPrefKey).apply();
        editor.putString(sharedPrefKey, json);
        editor.commit();
    }

    /*To get recipes. Not used currently*/
    public static ArrayList<Recipe> getSharedPreference(Context context){
        Gson gson=new Gson();
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREFERENCE_NAME, MODE_PRIVATE);
        String response=sharedPreferences.getString(SHARED_PREFERENCE_KEY,"");
        return gson.fromJson(response,new TypeToken<List<Recipe>>(){}.getType());
    }

    public static void setIngredientSharedPreference(Context context,List<Ingredient> ingredientShared) {
        String sharedPrefKey = SHARED_PREFERENCE_KEY_IN;
        //String prefName = SHARED_PREFERENCE_NAME;
        SharedPreferences sharedPreferences;
        SharedPreferences.Editor editor;
        sharedPreferences = context.getSharedPreferences(SHARED_PREFERENCE_NAME, MODE_PRIVATE);
        Gson gson = new Gson();
        String json = gson.toJson(ingredientShared);
        editor = sharedPreferences.edit();
        editor.remove(sharedPrefKey).apply();
        editor.putString(sharedPrefKey, json);
        editor.commit();
    }

    public static List<Ingredient> getIngredientSharedPreference(Context context){
        Gson gson=new Gson();
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREFERENCE_NAME, MODE_PRIVATE);
        String response=sharedPreferences.getString(SHARED_PREFERENCE_KEY_IN,"");
        return gson.fromJson(response,new TypeToken<List<Ingredient>>(){}.getType());
    }
}
