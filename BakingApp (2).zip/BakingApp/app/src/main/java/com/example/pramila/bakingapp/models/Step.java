package com.example.pramila.bakingapp.models;

import java.io.Serializable;

/**
 * Created by pramila on 20-08-2018 in ${Package_Name}.
 */
//"steps": [
//      {
//        "id": 0,
//        "shortDescription": "Recipe Introduction",
//        "description": "Recipe Introduction",
//        "videoURL": "https://d17h27t6h515a5.cloudfront.net/topher/2017/April/58ffd974_-intro-creampie/-intro-creampie.mp4",
//        "thumbnailURL": ""
//      },
public class Step implements Serializable {
    private String id;
    private String shortDescription;
    private String description;
    private String videoUrl;
    private String thumbnailUrl;
    private String recipeId;

    public Step(String recipeId, String id, String shortDescription, String description, String videoUrl, String thumbnailUrl) {
        this.recipeId = recipeId;
        this.id = id;
        this.shortDescription = shortDescription;
        this.description = description;
        this.videoUrl = videoUrl;
        this.thumbnailUrl = thumbnailUrl;
    }

    public String getRecipeId() {
        return recipeId;
    }

    public void setRecipeId(String recipeId) {
        this.recipeId = recipeId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }
}
