package com.example.pramila.bakingapp.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.pramila.bakingapp.R;
import com.example.pramila.bakingapp.models.Step;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by pramila on 26-08-2018 in ${Package_Name}.
 */
public class StepRecyclerViewAdapter extends RecyclerView.Adapter<StepRecyclerViewAdapter.ViewHolder> {
    private ArrayList<Step> steps;
    private Context mContext;
    private OnListFragmentListener mListener;

    public StepRecyclerViewAdapter(Context mContext,ArrayList<Step> steps, OnListFragmentListener onListFragmentListener) {
        this.steps = steps;
        this.mContext = mContext;
        this.mListener=onListFragmentListener;
    }

    public interface OnListFragmentListener{
        void onClick(Step stepData);
    }


    public ArrayList<Step> getSteps() {
        return steps;
    }

    public void setSteps(ArrayList<Step> steps) {
        this.steps = steps;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_ingredient, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        int stepNo=Integer.parseInt(steps.get(position).getId())+1;
        holder.mbullet.setText(String.valueOf(stepNo));
        holder.mIngredientText.setText(steps.get(position).getShortDescription());
    }

    @Override
    public int getItemCount() {
        return (steps!=null)?steps.size():0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        @BindView(R.id.bullet) TextView mbullet;
        @BindView(R.id.ingredient_name) TextView mIngredientText;

        public ViewHolder(View view) {
            super(view);
            //mView = view;
            /*mbullet = view.findViewById(R.id.bullet);
            mIngredientText = view.findViewById(R.id.ingredient_name);*/
            ButterKnife.bind(this,view);
            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int itemClickedPosition=getAdapterPosition();
            Step step=steps.get(itemClickedPosition);
            mListener.onClick(step);
        }
    }
}
