package com.example.pramila.bakingapp.widgetClasses;

import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import com.example.pramila.bakingapp.R;
import com.example.pramila.bakingapp.models.Ingredient;
import com.example.pramila.bakingapp.utils.Constant;

import java.util.ArrayList;
import java.util.List;

//import static com.example.pramila.bakingapp.widgetClasses.BakingAppWidget.ingredientsList;

/**
 * Created by pramila on 09-09-2018 in ${Package_Name}.
 */
public class ListWidgetService extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new ListRemoteViewFactory(this.getApplicationContext(),intent);
    }
}
class ListRemoteViewFactory implements RemoteViewsService.RemoteViewsFactory{

    private Context mContext;
    private List<Ingredient> widgetIngredientList=new ArrayList<>();

    public ListRemoteViewFactory(Context mContext , Intent intent) {
        this.mContext = mContext;
    }

    @Override
    public void onCreate() {
        widgetIngredientList=Constant.getIngredientSharedPreference(mContext);
    }

    @Override
    public void onDataSetChanged() {
        widgetIngredientList=Constant.getIngredientSharedPreference(mContext);
    }

    @Override
    public void onDestroy() {
        widgetIngredientList.clear();
    }

    @Override
    public int getCount() {
        return widgetIngredientList.size();
    }

    @Override
    public RemoteViews getViewAt(int i) {
        RemoteViews views=new RemoteViews(mContext.getPackageName(), R.layout.widget_grid_view_detail);
        String ingredientText=widgetIngredientList.get(i).getIngredient_name()+" - "
                + widgetIngredientList.get(i).getQuantity()+" "+widgetIngredientList.get(i).getMeasure();
        views.setTextViewText(R.id.grid_widget_text_view, ingredientText);
        Intent fillIntent=new Intent();
        views.setOnClickFillInIntent(R.id.grid_widget_text_view,fillIntent);
        return views;
    }

    @Override
    public RemoteViews getLoadingView() {
        return null;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }
}
