package com.example.pramila.bakingapp.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.pramila.bakingapp.adapters.IngredientRecyclerViewAdapter;
import com.example.pramila.bakingapp.R;
import com.example.pramila.bakingapp.adapters.StepRecyclerViewAdapter;
import com.example.pramila.bakingapp.models.Ingredient;
import com.example.pramila.bakingapp.models.Step;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * A fragment representing a list of Items.
 * <p/>
 * Activities containing this fragment MUST implement the {@link //OnListFragmentInteractionListener}
 * interface.
 */
public class IngredientFragment extends Fragment{
    @BindView(R.id.ingredients_recycler_view)RecyclerView ingredientRecyclerView;
    @BindView(R.id.steps_recycler_view) RecyclerView stepRecyclerView;
    StepRecyclerViewAdapter.OnListFragmentListener onListFragmentListener=null;
    ArrayList<Ingredient> ingredientList=new ArrayList<>();
    ArrayList<Step> stepArrayList=new ArrayList<>();
    IngredientRecyclerViewAdapter ingredientAdapter;
    StepRecyclerViewAdapter stepRecyclerViewAdapter;
    // TODO: Customize parameter argument names
    private static final String ARG_COLUMN_COUNT = "column-count";
    // TODO: Customize parameters
    private int mColumnCount = 1;
    //private OnListFragmentInteractionListener mListener;

    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public IngredientFragment() {
    }

    // TODO: Customize parameter initialization
    @SuppressWarnings("unused")
    public static IngredientFragment newInstance(int columnCount) {
        IngredientFragment fragment = new IngredientFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COLUMN_COUNT, columnCount);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
        /*if (getArguments() != null)
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);*/
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.recipe_ingredient_view, container, false);
        ButterKnife.bind(this,view);
        setRetainInstance(true);
       LinearLayoutManager linearLayoutManager=new LinearLayoutManager(getActivity());
       linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
       ingredientRecyclerView.setLayoutManager(linearLayoutManager);
       ingredientAdapter=new IngredientRecyclerViewAdapter(getContext(),ingredientList);
       ingredientRecyclerView.setHasFixedSize(true);
       ingredientRecyclerView.setAdapter(ingredientAdapter);

        LinearLayoutManager linearLayoutManager1=new LinearLayoutManager(getActivity());
        linearLayoutManager1.setOrientation(LinearLayoutManager.VERTICAL);
        stepRecyclerView.setLayoutManager(linearLayoutManager1);
        stepRecyclerViewAdapter=new StepRecyclerViewAdapter(getContext(),stepArrayList, onListFragmentListener);
        stepRecyclerView.setHasFixedSize(true);
        stepRecyclerView.setAdapter(stepRecyclerViewAdapter);
       return view;
    }

    public ArrayList<Ingredient> getIngredientList() {
        return ingredientList;
    }

    public void setIngredientList(List<Ingredient> ingredientList) {
        this.ingredientList.addAll(ingredientList);
    }

    public ArrayList<Step> getStepArrayList() {
        return stepArrayList;
    }

    public void setStepArrayList(List<Step> stepList) {
        this.stepArrayList.addAll(stepList);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
       /* if (context instanceof OnListFragmentInteractionListener) {
            mListener = (OnListFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnListFragmentInteractionListener");
        }*/
    }

    @Override
    public void onDetach() {
        super.onDetach();
        /*mListener = null;*/
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
   /* public interface OnListFragmentInteractionListener {
        // TODO: Update argument type and name
        void onListFragmentInteraction(Ingredient item);
    }*/

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        setRetainInstance(true);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        ingredientRecyclerView.setLayoutManager(linearLayoutManager);
        ingredientAdapter=new IngredientRecyclerViewAdapter(getContext(),ingredientList);
        ingredientRecyclerView.setHasFixedSize(true);
        ingredientRecyclerView.setAdapter(ingredientAdapter);

        LinearLayoutManager linearLayoutManager1=new LinearLayoutManager(getActivity());
        linearLayoutManager1.setOrientation(LinearLayoutManager.VERTICAL);
        stepRecyclerView.setLayoutManager(linearLayoutManager1);
        stepRecyclerViewAdapter=new StepRecyclerViewAdapter(getContext(),stepArrayList, onListFragmentListener);
        stepRecyclerView.setHasFixedSize(true);
        stepRecyclerView.setAdapter(stepRecyclerViewAdapter);
    }

    public StepRecyclerViewAdapter.OnListFragmentListener getOnListFragmentListener() {
        return onListFragmentListener;
    }

    public void setOnListFragmentListener(StepRecyclerViewAdapter.OnListFragmentListener onListFragmentListener) {
        this.onListFragmentListener = onListFragmentListener;
    }

    /*@Override
    public void onClick(Step stepData) {
        if(stepData==null)return;
        Toast.makeText(getContext(), "Step:"+stepData.getShortDescription(), Toast.LENGTH_SHORT).show();
        Intent stepDetailIntent=new Intent(getContext(),StepDetailActivity.class);
        stepDetailIntent.putExtra("stepData",stepData);
        startActivity(stepDetailIntent);
    }*/
}
