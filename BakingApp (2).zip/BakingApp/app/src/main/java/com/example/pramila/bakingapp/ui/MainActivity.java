package com.example.pramila.bakingapp.ui;

import android.content.Intent;
import android.content.res.Configuration;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.VisibleForTesting;
import android.support.test.espresso.IdlingResource;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pramila.bakingapp.IdlingResource.SimpleIdlingResource;
import com.example.pramila.bakingapp.R;
import com.example.pramila.bakingapp.adapters.RecipeAdapter;
import com.example.pramila.bakingapp.models.Recipe;
import com.example.pramila.bakingapp.utils.Constant;
import com.example.pramila.bakingapp.utils.JsonUtils;
import com.example.pramila.bakingapp.utils.NetworkUtils;

import java.net.URL;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<ArrayList<Recipe>>, RecipeAdapter.RecipeAdapterOnClickHandler {
    private static final int RECIPE_LOADER=27;
    @BindView(R.id.progressBar) ProgressBar progressBar;
    @BindView(R.id.recipes_recycler_view) RecyclerView recyclerView;
    @BindView(R.id.tv_error) TextView errorTxtView;
    RecipeAdapter recipeAdapter;
    @BindView(R.id.retry) Button retryBtn;
    ArrayList<Recipe> recipesList=new ArrayList<>();
    @Nullable private SimpleIdlingResource mIdlingResource;

    @VisibleForTesting
    public IdlingResource getIdlingResource(){
        if (mIdlingResource==null)
            mIdlingResource=new SimpleIdlingResource();
        return mIdlingResource;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        //setTitle("Baking Time");
        setTitle(getResources().getString(R.string.baking_time));
        recyclerView.setVisibility(View.INVISIBLE);
        if(Constant.checkInternetConnection(this)){
            getSupportLoaderManager().initLoader(RECIPE_LOADER,null, this);
            getIdlingResource();
        }else {
            showError();
        }
        retryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Constant.checkInternetConnection(getApplicationContext()))
                    getSupportLoaderManager().restartLoader(RECIPE_LOADER,null,MainActivity.this);
            }
        });
        setRecyclerView(recipesList);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList("recipe",recipesList);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        recipesList=savedInstanceState.getParcelableArrayList("recipe");
    }

   /* public void setRecyclerView(Configuration conf, ArrayList<Recipe> recipes){
        int spanCount=conf.orientation==Configuration.ORIENTATION_LANDSCAPE?2:1;
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager=new GridLayoutManager(getApplicationContext(),spanCount);
        //RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(layoutManager);
        recipeAdapter=new RecipeAdapter(this,recipes,this);
        recyclerView.setAdapter(recipeAdapter);
    }*/
    public void setRecyclerView(ArrayList<Recipe> recipes){
        //int spanCount=conf.orientation==Configuration.ORIENTATION_LANDSCAPE?2:1;
        int spanCount=getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE ? 2 : 1;
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager=new GridLayoutManager(getApplicationContext(),spanCount);
        //RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(layoutManager);
        recipeAdapter=new RecipeAdapter(this,recipes,this);
        recyclerView.setAdapter(recipeAdapter);
    }


    /*@Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        setRecyclerView(newConfig,recipesList);
    }*/

    @NonNull
    @Override
    public Loader<ArrayList<Recipe>> onCreateLoader(int i, Bundle bundle) {
        return new AsyncTaskLoader<ArrayList<Recipe>>(this) {
            @Override
            protected void onStartLoading() {
                super.onStartLoading();
                showProgressbar();
                forceLoad();
            }

            @Override
            public ArrayList<Recipe> loadInBackground() {
                try{
                    URL recipeUrl= NetworkUtils.buildUrl(Constant.RECIPE_BASIC_URL);
                    String responseRecipeData=NetworkUtils.getResponseFromHttpUrl(recipeUrl);
                    return JsonUtils.getRecipes(responseRecipeData);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return null;
            }
        };
    }


    @Override
    public void onLoadFinished(@NonNull Loader<ArrayList<Recipe>> loader, ArrayList<Recipe> recipes) {
        if(!recipes.isEmpty() && recipes!=null){
            recipeAdapter.setRecipes(recipes);
            recipesList=recipes;
            showData();
        }else
            showError();
    }

    @Override
    public void onLoaderReset(@NonNull Loader<ArrayList<Recipe>> loader) {
        recipeAdapter=null;
    }

    @Override
    public void onClick(Recipe recipesData) {
        /*Toast.makeText(this,"Name"+recipesData.getName()+"Ingredients:"+recipesData.getIngredients().size()+"Steps:"+
                recipesData.getSteps().size(),Toast.LENGTH_SHORT).show();*/
        Intent recipeDetailIntent=new Intent(this,RecipeDetailActivity.class);
        recipeDetailIntent.putExtra(Constant.RECIPE_INTENT_EXTRA,recipesData);
        Constant.setIngredientSharedPreference(this,recipesData.getIngredients());
        //Toast.makeText(this,"Recipe name:"+Constant.getIngredientSharedPreference(this).get(0).getRecipeId(),Toast.LENGTH_SHORT).show();
        startActivity(recipeDetailIntent);
    }
    public void showProgressbar(){
        progressBar.setVisibility(View.VISIBLE);
        recyclerView.setVisibility(View.INVISIBLE);
        errorTxtView.setVisibility(View.INVISIBLE);
        retryBtn.setVisibility(View.INVISIBLE);
    }

    public void showData(){
        progressBar.setVisibility(View.INVISIBLE);
        errorTxtView.setVisibility(View.INVISIBLE);
        retryBtn.setVisibility(View.INVISIBLE);
        recyclerView.setVisibility(View.VISIBLE);
    }

    public void showError(){
        progressBar.setVisibility(View.INVISIBLE);
        recyclerView.setVisibility(View.INVISIBLE);
        errorTxtView.setVisibility(View.VISIBLE);
        retryBtn.setVisibility(View.VISIBLE);
    }
}
