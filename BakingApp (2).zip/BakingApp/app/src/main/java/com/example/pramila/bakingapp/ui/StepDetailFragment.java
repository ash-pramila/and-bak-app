package com.example.pramila.bakingapp.ui;

import android.content.Context;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pramila.bakingapp.R;
import com.example.pramila.bakingapp.adapters.RecipeAdapter;
import com.example.pramila.bakingapp.models.Step;
import com.example.pramila.bakingapp.utils.Constant;
import com.google.android.exoplayer2.C;
import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.LoadControl;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.ui.AspectRatioFrameLayout;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;
import com.google.android.exoplayer2.util.Util;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link //StepDetailFragment.//OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link StepDetailFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class StepDetailFragment extends Fragment{
    @BindView(R.id.video_player) SimpleExoPlayerView mPlayerView;
    @BindView(R.id.step_text) TextView mStepDetailText;
    @BindView(R.id.step_image) ImageView mThumbnailImage;
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    SimpleExoPlayer mExoPlayer;
    Step step;String videoUri;
    private long mPlayerPosition=0;
    private int mPlayerWindowIndex=0;
    private boolean mPlayWhenReady=true;
    //private boolean isImage=false;
    /*private int mResumeWindow;
    private long mResumePosition;*/
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    //private OnFragmentInteractionListener mListener;

    public StepDetailFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment StepDetailFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static StepDetailFragment newInstance(String param1, String param2) {
        StepDetailFragment fragment = new StepDetailFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_step_detail, container, false);
        ButterKnife.bind(this,view);
        return view;
    }

    public Step getStep() {
        return step;
    }

    public void setStep(Step step) {
        this.step = step;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        setRetainInstance(true);
        if(savedInstanceState!=null){
            step=(Step)savedInstanceState.getSerializable(Constant.RECIPE_STEP);
            //isImage=savedInstanceState.getBoolean(Constant.SAVED_IS_IMAGE);
            if(mExoPlayer!=null){
                mPlayerPosition=savedInstanceState.getLong(Constant.SAVE_PLAYER_POSITION_KEY,0);
                mPlayerWindowIndex=savedInstanceState.getInt(Constant.SAVED_PLAYER_WINDOW_INDEX,0);
                mPlayWhenReady=savedInstanceState.getBoolean(Constant.SAVED_PLAY_STATE,true);
            }
        }
        changeVideoSizeAccordingToOrientation();
        mStepDetailText.setText(step.getDescription());
        videoUri=step.getVideoUrl();
        String thumbnailUrl=step.getThumbnailUrl();
        if(videoUri==null || videoUri.isEmpty()){
            if (thumbnailUrl.endsWith(".mp4")){
                mThumbnailImage.setVisibility(View.INVISIBLE);
                mPlayerView.setVisibility(View.VISIBLE);
                initializePlayer(thumbnailUrl);
                //isImage=false;
            }else {
                mPlayerView.setVisibility(View.INVISIBLE);
                RecipeAdapter.setImage(getActivity(), thumbnailUrl, mThumbnailImage);
                mThumbnailImage.setVisibility(View.VISIBLE);
                //mStepDetailText.setVisibility(View.VISIBLE);
                setThumbnailImageInLandscape();
                //isImage=true;
            }
        }
        else if(videoUri.endsWith(".mp4")) {
            mThumbnailImage.setVisibility(View.INVISIBLE);
            mPlayerView.setVisibility(View.VISIBLE);
            initializePlayer(videoUri);
            //isImage=false;
        }/*else if(thumbnailUrl.endsWith(".mp4")){
            mThumbnailImage.setVisibility(View.INVISIBLE);
            mPlayerView.setVisibility(View.VISIBLE);
            initializePlayer(thumbnailUrl);
        }*/
        /*String visible=mStepDetailText.getVisibility()==View.VISIBLE?"Visible":"Invisible";
        //Toast.makeText(getContext(),visible+" Step text"+mStepDetailText.getText().toString(),Toast.LENGTH_SHORT).show();*/
    }

    private void initializePlayer(String mediaUrl){
        if(mExoPlayer==null && mediaUrl!=null && !mediaUrl.isEmpty()){
            TrackSelector trackSelector=new DefaultTrackSelector();
            LoadControl loadControl=new DefaultLoadControl();
            mExoPlayer= ExoPlayerFactory.newSimpleInstance(getContext(),trackSelector,loadControl);
            mPlayerView.setPlayer(mExoPlayer);
            //mExoPlayer.addListener(getContext());
            //mExoPlayer.setPlayWhenReady(true);
            String userAgent= Util.getUserAgent(getContext(),"BakingApp");
            DefaultExtractorsFactory extractorsFactory=new DefaultExtractorsFactory();
            MediaSource mediaSource=new ExtractorMediaSource(Uri.parse(mediaUrl),new DefaultHttpDataSourceFactory(userAgent),extractorsFactory,null,null);
            mPlayerView.requestFocus();
            mExoPlayer.seekTo(mPlayerWindowIndex,mPlayerPosition);
            mExoPlayer.prepare(mediaSource);
            mExoPlayer.setPlayWhenReady(mPlayWhenReady);
        }
    }

    private void releasePlayer(){
        if(mExoPlayer!=null) {
            mExoPlayer.stop();
            mExoPlayer.release();
            mExoPlayer = null;
        }
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        /*if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
       /* if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }*/
    }

    @Override
    public void onDetach() {
        super.onDetach();
        //mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    /*public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }*/

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(mExoPlayer!=null) {
            releasePlayer();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if(mExoPlayer!=null) {
            if (Util.SDK_INT > 23)
                releasePlayer();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if(mExoPlayer!=null) {
            mPlayerWindowIndex=mExoPlayer.getCurrentWindowIndex();
            mPlayerPosition=mExoPlayer.getCurrentPosition();
            mPlayWhenReady=mExoPlayer.getPlayWhenReady();
            if (Util.SDK_INT <= 23)
                releasePlayer();
        }
    }



    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putSerializable(Constant.RECIPE_STEP,step);
        if(mExoPlayer!=null) {
            outState.putLong(Constant.SAVE_PLAYER_POSITION_KEY, mExoPlayer.getCurrentPosition());
            outState.putInt(Constant.SAVED_PLAYER_WINDOW_INDEX,mExoPlayer.getCurrentWindowIndex());
            outState.putBoolean(Constant.SAVED_PLAY_STATE,mExoPlayer.getPlayWhenReady());
            //outState.putBoolean(Constant.SAVED_IS_IMAGE,isImage);
        }
    }

    public void changeVideoSizeAccordingToOrientation(){
        boolean landscape= isLandscapeOrientation();
        if(landscape && !RecipeDetailActivity.ismTwoPane()){
            /*getActivity().getWindow().requestFeature(Window.FEATURE_ACTION_BAR);
            getActivity().getActionBar().hide();*/
            mStepDetailText.setVisibility(View.GONE);
            FrameLayout.LayoutParams params=(FrameLayout.LayoutParams)mPlayerView.getLayoutParams();
            params.width=params.MATCH_PARENT;
            params.height=params.MATCH_PARENT;
            mPlayerView.setLayoutParams(params);
            getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            ((AppCompatActivity) getActivity()).getSupportActionBar().hide();
            mPlayerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);
            //getActivity().getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE);
        }else{
            getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            ((AppCompatActivity) getActivity()).getSupportActionBar().show();
            FrameLayout.LayoutParams params=(FrameLayout.LayoutParams)mPlayerView.getLayoutParams();
            params.width=params.MATCH_PARENT;
            params.height=Constant.VIDEO_POTRAIT_SIZE;
            mPlayerView.setLayoutParams(params);
            mStepDetailText.setVisibility(View.VISIBLE);
            //getActivity().getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            //mPlayerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);
        }
    }

    public void setThumbnailImageInLandscape(){
        if(mThumbnailImage.getVisibility()==View.VISIBLE && isLandscapeOrientation()){
            //Toast.makeText(getContext(),"Image",Toast.LENGTH_SHORT).show();
            FrameLayout.LayoutParams params=(FrameLayout.LayoutParams)mPlayerView.getLayoutParams();
            params.width=params.MATCH_PARENT;
            params.height=Constant.VIDEO_SIZE_FOR_IMAGE_IN_LAND;
            mPlayerView.setLayoutParams(params);
            mStepDetailText.setVisibility(View.VISIBLE);
        }
    }

    public boolean isLandscapeOrientation(){
        return getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
    }
}
