package com.example.pramila.bakingapp.models;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;

import java.io.Serializable;

/**
 * Created by pramila on 20-08-2018 in ${Package_Name}.
 */
//ingredients": [
//      {
//        "quantity": 2,
//        "measure": "CUP",
//        "ingredient": "Graham Cracker crumbs"
//      },
public class Ingredient implements Serializable {
    private int id;//room
    private String recipeId;
    private String quantity;
    private String measure;
    private String ingredient_name;

    public Ingredient(String id, String quantity, String measure, String ingredient_name) {
        this.recipeId =id;
        this.quantity = quantity;
        this.measure = measure;
        this.ingredient_name = ingredient_name;
    }
    public Ingredient(int id,String recipeId, String quantity, String measure, String ingredient_name) {
        this.id=id;
        this.recipeId =recipeId;
        this.quantity = quantity;
        this.measure = measure;
        this.ingredient_name = ingredient_name;
    }

    public String getRecipeId() {
        return recipeId;
    }

    public void setRecipeId(String recipeId) {
        this.recipeId = recipeId;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getMeasure() {
        return measure;
    }

    public void setMeasure(String measure) {
        this.measure = measure;
    }

    public String getIngredient_name() {
        return ingredient_name;
    }

    public void setIngredient_name(String ingredient_name) {
        this.ingredient_name = ingredient_name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
