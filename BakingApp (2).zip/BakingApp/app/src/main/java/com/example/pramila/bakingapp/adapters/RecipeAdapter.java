package com.example.pramila.bakingapp.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.pramila.bakingapp.R;
import com.example.pramila.bakingapp.models.Recipe;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by pramila on 19-08-2018 in ${Package_Name}.
 */
public class RecipeAdapter extends RecyclerView.Adapter<RecipeAdapter.ViewHolder>{
    private Context context;
    private ArrayList<Recipe> recipes;
    private RecipeAdapterOnClickHandler recipeAdapterOnClickHandler;


    public RecipeAdapter(Context context, ArrayList<Recipe> recipes, RecipeAdapterOnClickHandler recipeAdapterOnClickHandler) {
        this.context = context;
        this.recipes = recipes;
        this.recipeAdapterOnClickHandler = recipeAdapterOnClickHandler;
    }

    public interface RecipeAdapterOnClickHandler{
        void onClick(Recipe recipesData);
    }

    public void setRecipes(ArrayList<Recipe> recipeList){
        recipes=recipeList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.recipe_view,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        setImage(context,recipes.get(position).getImage(),holder.recipeImage);
        holder.recipeName.setText(recipes.get(position).getName());
        String step="Steps: "+String.valueOf(recipes.get(position).getSteps().size());
        holder.recipeSteps.setText(step);
        String ingredients="Ingredients: "+String.valueOf(recipes.get(position).getIngredients().size());
        holder.recipeIngredients.setText(ingredients);
    }

    public static void setImage(Context context,String imageUrl, ImageView image){
        if(imageUrl!=null && !imageUrl.isEmpty()) {
            Picasso.with(context)
                    .load(imageUrl)
                    .placeholder(R.drawable.recipe_cook)
                    .error(R.drawable.recipe_cook)
                    .into(image);
        }else {
            image.setImageResource(R.drawable.recipe_cook);
        }
    }

    @Override
    public int getItemCount() {
        return (recipes!=null)?recipes.size():0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        @BindView(R.id.recipe_image) ImageView recipeImage;
        @BindView(R.id.recipe_name)TextView recipeName;
        @BindView(R.id.recipe_steps) TextView recipeSteps;
        @BindView(R.id.recipe_ingredients) TextView recipeIngredients;

        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this,itemView);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int itemClickedPosition=getAdapterPosition();
            Recipe recipeData=recipes.get(itemClickedPosition);
            recipeAdapterOnClickHandler.onClick(recipeData);
        }
    }
}
